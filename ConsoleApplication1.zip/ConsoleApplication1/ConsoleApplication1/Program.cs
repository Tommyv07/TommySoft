﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Apis.Customsearch;
using Google.Apis.Services;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] args1 = Environment.GetCommandLineArgs();
            const string apiKey = "AIzaSyD5evWgbRNqy8XYt3isyCUMTeMnUer_ZaM";
            const string searchgoogleEngineId = "012523857031743671906:6be11n0j38i";
            const string searchmsnEngineId = "012523857031743671906:m2xrxkhlwoe";
            int count = 0;
            string argtot = "";
            string argwingoo = "";
            string argwinmsn = "";
            int count3 = 0;
            int count6 = 0;

            foreach (string arg in args1)
            {
                if (count > 0)
                {
                    string query = arg;
                    var customSearchService = new Google.Apis.Customsearch.v1.CustomsearchService(new BaseClientService.Initializer { ApiKey = apiKey });
                    var listRequestgoogle = customSearchService.Cse.List(query);
                    var listRequestmsn = customSearchService.Cse.List(query);
                    listRequestgoogle.Cx = searchgoogleEngineId;
                    listRequestmsn.Cx = searchmsnEngineId;

                    IList<Google.Apis.Customsearch.v1.Data.Result> pagin = new List<Google.Apis.Customsearch.v1.Data.Result>();

                    int count1 = 0;
                    int count2 = 0;

                    while (pagin != null)
                    {
                        listRequestgoogle.Start = count1 * 10 + 1;
                        pagin = listRequestgoogle.Execute().Items;

                        if (pagin != null)
                        {
                            count2 = count2 + pagin.Count;
                            count1++;
                        }
                    }

                    int count4 = 0;
                    int count5 = 0;

                    while (pagin != null)
                    {
                        listRequestmsn.Start = count4 * 10 + 1;
                        pagin = listRequestmsn.Execute().Items;

                        if (pagin != null)
                        {
                            count5 = count5 + pagin.Count;
                            count4++;
                        }
                    }

                    if (count2+count5 >= count3+count6)
                    {
                        argtot = arg;
                    }
                    if (count2 >= count3)
                    {
                        argwingoo = arg;
                    }
                    if (count5 >= count6)
                    {
                        argwinmsn = arg;
                    }

                    count3 = count2;
                    count6 = count5;

                    Console.WriteLine(arg + ": Google: " + count3.ToString() + " MSN Search: " + count6.ToString());
                }
                count++;
            }
            Console.WriteLine("Google winner: " + argwingoo);
               Console.WriteLine("MSN Search winner: " + argwinmsn);
            Console.WriteLine("Total winner: " + argtot);
        }
    }
}
